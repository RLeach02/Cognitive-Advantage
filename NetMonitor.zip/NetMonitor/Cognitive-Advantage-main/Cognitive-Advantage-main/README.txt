# Cognitive Advantage
IT Project Capstone
Gobi made an edit to the readme
Gobi is making an edit to creat a different version of the readme 
Pat is making an edit
Pat is making an edit second time
